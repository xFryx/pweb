<template>
    <v-app>
        <v-main>
            
        </v-main>
    </v-app>
</template>
<script>
export default {
    data(){
        return {

        }
    },
}
</script>