module.exports = {
  transpileDependencies: [
    'vuetify'
  ],
}
